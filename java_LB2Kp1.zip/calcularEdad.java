import java.util.Calendar;
import java.util.GregorianCalendar;
 
public class calcularEdad {
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		// Mostramos el resultado de llamar a la funcion calcular pasando
		// como parametro la fecha de nacimiento YYYY-MM-DD
		System.out.println(calcular(new GregorianCalendar(1978,03,04)));
	}
 
    public static int calcular(Calendar fechaNac) {
        Calendar fechaActual = Calendar.getInstance();
 
        // Calculo de las diferencias.
        int years = fechaActual.get(Calendar.YEAR) - fechaNac.get(Calendar.YEAR);
        int months = fechaActual.get(Calendar.MONTH) - fechaNac.get(Calendar.MONTH);
        int days = fechaActual.get(Calendar.DAY_OF_MONTH) - fechaNac.get(Calendar.DAY_OF_MONTH);
 
        // Hay que comprobar si el dia de su cumpleanios es posterior
        // a la fecha actual, para restar 1 a la diferencia de anios,
        // pues aun no ha sido su cumpleanios.
 
        if(months < 0 // Aun no es el mes de su cumpleanios
           || (months==0 && days < 0)) { // o es el mes pero no ha llegado el dia.
            years--;
        }
        return years;
    }
}